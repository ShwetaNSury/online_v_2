
  # Online Voting System Website

  This is a code bundle for Online Voting System Website. The original project is available at https://www.figma.com/design/FzPob6B4gpOFyp5oZElY89/Online-Voting-System-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  