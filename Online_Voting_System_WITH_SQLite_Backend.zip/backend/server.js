import express from "express";
import cors from "cors";
import sqlite3 from "sqlite3";

const app = express();
app.use(cors());
app.use(express.json());

const db = new sqlite3.Database("./voting.db", (err) => {
  if (err) console.error(err.message);
  else console.log("Connected to SQLite database");
});

db.serialize(() => {
  db.run("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT, hasVoted INTEGER DEFAULT 0)");
  db.run("CREATE TABLE IF NOT EXISTS candidates (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, party TEXT, votes INTEGER DEFAULT 0)");
  db.run("INSERT INTO candidates (name, party) SELECT 'Candidate A','Party X' WHERE NOT EXISTS (SELECT 1 FROM candidates WHERE name='Candidate A')");
  db.run("INSERT INTO candidates (name, party) SELECT 'Candidate B','Party Y' WHERE NOT EXISTS (SELECT 1 FROM candidates WHERE name='Candidate B')");
});

// Register
app.post("/api/register", (req, res) => {
  const { name, email } = req.body;
  db.run("INSERT INTO users (name,email) VALUES (?,?)",[name,email], function(err){
    if(err) return res.status(500).json({error:err.message});
    res.json({id:this.lastID, name, email});
  });
});

// Get Candidates
app.get("/api/candidates", (req,res)=>{
  db.all("SELECT * FROM candidates",[],(err,rows)=>{
    if(err) return res.status(500).json({error:err.message});
    res.json(rows);
  });
});

// Vote (one vote per user not enforced here - simple version)
app.post("/api/vote/:id",(req,res)=>{
  db.run("UPDATE candidates SET votes=votes+1 WHERE id=?",[req.params.id], function(err){
    if(err) return res.status(500).json({error:err.message});
    res.json({message:"Vote counted"});
  });
});

// Results
app.get("/api/results",(req,res)=>{
  db.all("SELECT * FROM candidates",[],(err,rows)=>{
    if(err) return res.status(500).json({error:err.message});
    res.json(rows);
  });
});

app.listen(5000, ()=> console.log("Backend running on http://localhost:5000"));
