// Admin Portal functionality
let currentAdminTab = 'dashboard';
let currentRegTab = 'pending';
let candidateCount = 2;
let deleteElectionId = null;
let reviewRegistrationId = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    checkAdminAuth();
    initializeAdminTabs();
    initializeRegTabs();
    initializeCreateElectionForm();
    renderDashboard();
    renderAdminElections();
    renderRegistrations();
});

function checkAdminAuth() {
    const user = window.appUtils.getCurrentUser();
    if (!user || user.role !== 'admin') {
        window.appUtils.showToast('Unauthorized access', 'error');
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 500);
        return;
    }
    
    const adminName = document.getElementById('adminName');
    if (adminName) {
        adminName.textContent = user.name;
    }
}

function switchToVoterView() {
    window.location.href = 'index.html';
}

// Admin Tabs
function initializeAdminTabs() {
    const tabButtons = document.querySelectorAll('.admin-tab-button');
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const tab = button.getAttribute('data-tab');
            currentAdminTab = tab;
            
            document.querySelectorAll('.admin-tab-button').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.admin-tab-content').forEach(content => content.classList.remove('active'));
            
            button.classList.add('active');
            document.getElementById(`${tab}-content`).classList.add('active');
            
            // Refresh content based on tab
            if (tab === 'dashboard') renderDashboard();
            if (tab === 'elections') renderAdminElections();
            if (tab === 'voter-registration') renderRegistrations();
        });
    });
}

// Dashboard
function renderDashboard() {
    const elections = window.appUtils.getElections();
    const totalVoters = 5000;
    const activeElections = elections.filter(e => window.appUtils.getElectionStatus(e) === 'active');
    const totalVotes = elections.reduce((sum, e) => sum + e.totalVotes, 0);
    
    document.getElementById('dashTotalVoters').textContent = totalVoters.toLocaleString();
    document.getElementById('dashTotalElections').textContent = elections.length;
    document.getElementById('dashActiveElections').textContent = activeElections.length;
    document.getElementById('dashTotalVotes').textContent = totalVotes.toLocaleString();
    
    // Render recent activity
    const activityList = document.getElementById('activityList');
    const activities = [
        'New voter registration submitted',
        'Election "Student Council President" received 50 new votes',
        'Voter registration approved for john.smith@example.com',
        'New election "Class Representative" created'
    ];
    
    activityList.innerHTML = activities.map((activity, index) => `
        <div class="activity-item">
            <p>${activity}</p>
            <small>${index + 1} hour${index !== 0 ? 's' : ''} ago</small>
        </div>
    `).join('');
}

// Manage Elections
function renderAdminElections() {
    const elections = window.appUtils.getElections();
    const searchQuery = document.getElementById('adminSearchInput')?.value.toLowerCase() || '';
    
    const filteredElections = elections.filter(election => {
        return election.title.toLowerCase().includes(searchQuery) ||
               election.description.toLowerCase().includes(searchQuery);
    });
    
    const container = document.getElementById('adminElectionsList');
    if (!container) return;
    
    container.innerHTML = filteredElections.map(election => {
        const status = window.appUtils.getElectionStatus(election);
        const statusBadge = getStatusBadge(status);
        const turnout = window.appUtils.calculatePercentage(election.totalVotes, election.eligibleVoters);
        
        return `
            <div class="election-card">
                <div class="election-card-header">
                    <h3>${election.title}</h3>
                    <p>${election.description}</p>
                </div>
                <div class="election-card-meta">
                    ${statusBadge}
                    <span><i class="fas fa-calendar"></i> ${window.appUtils.formatDate(election.startDate)} - ${window.appUtils.formatDate(election.endDate)}</span>
                </div>
                <div class="election-card-stats">
                    <div class="stat-item">
                        <strong>${election.totalVotes}</strong>
                        <span>Votes</span>
                    </div>
                    <div class="stat-item">
                        <strong>${election.candidates.length}</strong>
                        <span>Candidates</span>
                    </div>
                    <div class="stat-item">
                        <strong>${turnout}%</strong>
                        <span>Turnout</span>
                    </div>
                </div>
                <div class="election-card-actions">
                    <button class="btn btn-secondary" onclick="viewElectionResults('${election.id}')">
                        <i class="fas fa-chart-bar"></i> Results
                    </button>
                    <button class="btn btn-danger" onclick="openDeleteModal('${election.id}')">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

function getStatusBadge(status) {
    const colors = {
        active: 'success',
        upcoming: 'warning',
        closed: 'secondary'
    };
    const labels = {
        active: 'Active',
        upcoming: 'Upcoming',
        closed: 'Closed'
    };
    
    return `<span class="badge" style="background-color: var(--${colors[status]}-color);">${labels[status]}</span>`;
}

// Search functionality
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('adminSearchInput');
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            renderAdminElections();
        });
    }
});

function viewElectionResults(electionId) {
    window.location.href = `results.html?id=${electionId}`;
}

// Delete Election
function openDeleteModal(electionId) {
    deleteElectionId = electionId;
    document.getElementById('deleteModal').classList.add('active');
}

function closeDeleteModal() {
    deleteElectionId = null;
    document.getElementById('deleteModal').classList.remove('active');
}

function confirmDelete() {
    if (!deleteElectionId) return;
    
    const elections = window.appUtils.getElections();
    const updatedElections = elections.filter(e => e.id !== deleteElectionId);
    window.appUtils.setElections(updatedElections);
    
    window.appUtils.showToast('Election deleted successfully', 'success');
    closeDeleteModal();
    renderAdminElections();
    renderDashboard();
}

// Create Election
function initializeCreateElectionForm() {
    const form = document.getElementById('createElectionForm');
    if (form) {
        form.addEventListener('submit', handleCreateElection);
    }
    
    // Add initial candidate fields
    addCandidate();
    addCandidate();
}

function addCandidate() {
    const candidatesList = document.getElementById('candidatesList');
    candidateCount++;
    
    const candidateDiv = document.createElement('div');
    candidateDiv.className = 'candidate-input-group';
    candidateDiv.innerHTML = `
        <input type="text" placeholder="Candidate Name" required>
        <input type="text" placeholder="Party/Affiliation" required>
        <button type="button" class="btn btn-danger btn-sm" onclick="this.parentElement.remove()">
            <i class="fas fa-trash"></i>
        </button>
    `;
    
    candidatesList.appendChild(candidateDiv);
}

function handleCreateElection(e) {
    e.preventDefault();
    
    const title = document.getElementById('electionTitle').value;
    const description = document.getElementById('electionDescription').value;
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    const eligibleVoters = parseInt(document.getElementById('eligibleVoters').value);
    
    // Get candidates
    const candidateGroups = document.querySelectorAll('#candidatesList .candidate-input-group');
    const candidates = Array.from(candidateGroups).map((group, index) => {
        const inputs = group.querySelectorAll('input');
        return {
            id: `${Date.now()}-${index}`,
            name: inputs[0].value,
            party: inputs[1].value,
            votes: 0
        };
    });
    
    // Determine status
    const now = new Date();
    const start = new Date(startDate);
    const status = start > now ? 'upcoming' : 'active';
    
    // Create new election
    const newElection = {
        id: Date.now().toString(),
        title,
        description,
        candidates,
        startDate,
        endDate,
        totalVotes: 0,
        status,
        eligibleVoters
    };
    
    const elections = window.appUtils.getElections();
    elections.unshift(newElection);
    window.appUtils.setElections(elections);
    
    window.appUtils.showToast('Election created successfully!', 'success');
    
    // Reset form
    e.target.reset();
    document.getElementById('candidatesList').innerHTML = '';
    candidateCount = 0;
    addCandidate();
    addCandidate();
    
    // Switch to manage elections tab
    document.querySelector('[data-tab="elections"]').click();
}

// Registration Management
function initializeRegTabs() {
    const tabButtons = document.querySelectorAll('.reg-tab-button');
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const tab = button.getAttribute('data-tab');
            currentRegTab = tab;
            
            document.querySelectorAll('.reg-tab-button').forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            
            // Show/hide lists
            document.getElementById('pendingList').style.display = tab === 'pending' ? 'flex' : 'none';
            document.getElementById('approvedList').style.display = tab === 'approved' ? 'flex' : 'none';
            document.getElementById('rejectedList').style.display = tab === 'rejected' ? 'flex' : 'none';
        });
    });
}

function renderRegistrations() {
    const registrations = window.appUtils.getPendingRegistrations();
    
    const pending = registrations.filter(r => r.status === 'pending');
    const approved = registrations.filter(r => r.status === 'approved');
    const rejected = registrations.filter(r => r.status === 'rejected');
    
    // Update badges
    document.getElementById('pendingBadge').textContent = pending.length;
    document.getElementById('approvedBadge').textContent = approved.length;
    document.getElementById('rejectedBadge').textContent = rejected.length;
    
    // Render lists
    renderRegistrationList('pendingList', pending);
    renderRegistrationList('approvedList', approved);
    renderRegistrationList('rejectedList', rejected);
}

function renderRegistrationList(containerId, registrations) {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    if (registrations.length === 0) {
        container.innerHTML = `
            <div style="width: 100%; text-align: center; padding: 3rem; color: #6b7280;">
                <p>No registrations in this category</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = registrations.map(reg => `
        <div class="registration-card">
            <div class="registration-card-header">
                <div>
                    <h4>${reg.name}</h4>
                    <p style="color: #6b7280; margin: 0;">${reg.email}</p>
                </div>
                <span class="badge" style="background-color: ${getStatusColor(reg.status)};">${reg.status}</span>
            </div>
            <div class="registration-card-body">
                <div class="info-item">
                    <strong>Phone</strong>
                    <span>${reg.phone}</span>
                </div>
                <div class="info-item">
                    <strong>Date of Birth</strong>
                    <span>${new Date(reg.dateOfBirth).toLocaleDateString()}</span>
                </div>
                <div class="info-item" style="grid-column: 1 / -1;">
                    <strong>Address</strong>
                    <span>${reg.address}</span>
                </div>
                <div class="info-item">
                    <strong>Registration Date</strong>
                    <span>${reg.registrationDate}</span>
                </div>
                ${reg.generatedVoterId ? `
                    <div class="info-item">
                        <strong>Voter ID</strong>
                        <span>${reg.generatedVoterId}</span>
                    </div>
                ` : ''}
            </div>
            <div class="registration-card-footer">
                <button class="btn btn-secondary btn-sm" onclick="reviewRegistration('${reg.id}')">
                    <i class="fas fa-eye"></i> Review
                </button>
                ${reg.status === 'pending' ? `
                    <button class="btn btn-success btn-sm" onclick="openVoterIdModal('${reg.id}')">
                        <i class="fas fa-check"></i> Approve
                    </button>
                    <button class="btn btn-danger btn-sm" onclick="rejectRegistrationPrompt('${reg.id}')">
                        <i class="fas fa-times"></i> Reject
                    </button>
                ` : ''}
                ${reg.status === 'approved' ? `
                    <button class="btn btn-primary btn-sm" onclick="viewVoterID('${reg.id}')">
                        <i class="fas fa-id-card"></i> View Voter ID
                    </button>
                ` : ''}
            </div>
        </div>
    `).join('');
}

function getStatusColor(status) {
    const colors = {
        pending: '#f59e0b',
        approved: '#10b981',
        rejected: '#ef4444'
    };
    return colors[status] || '#6b7280';
}

// Review Registration
function reviewRegistration(registrationId) {
    reviewRegistrationId = registrationId;
    const registrations = window.appUtils.getPendingRegistrations();
    const registration = registrations.find(r => r.id === registrationId);
    
    if (!registration) return;
    
    const modalBody = document.getElementById('reviewModalBody');
    modalBody.innerHTML = `
        <div class="review-container">
            <div class="review-section">
                <h4>Personal Information</h4>
                <div class="review-item">
                    <strong>Name:</strong>
                    <span>${registration.name}</span>
                </div>
                <div class="review-item">
                    <strong>Email:</strong>
                    <span>${registration.email}</span>
                </div>
                <div class="review-item">
                    <strong>Phone:</strong>
                    <span>${registration.phone}</span>
                </div>
                <div class="review-item">
                    <strong>Date of Birth:</strong>
                    <span>${new Date(registration.dateOfBirth).toLocaleDateString()}</span>
                </div>
                <div class="review-item">
                    <strong>Address:</strong>
                    <span>${registration.address}</span>
                </div>
            </div>
            
            <div class="review-section">
                <h4>Captured Documents</h4>
                <div class="review-documents">
                    <div class="review-doc">
                        <strong>Face Photo</strong>
                        <img src="${registration.facePhoto}" alt="Face photo">
                    </div>
                    <div class="review-doc">
                        <strong>ID Document</strong>
                        <img src="${registration.voterIdDocument}" alt="ID document">
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.getElementById('reviewModal').classList.add('active');
}

function closeReviewModal() {
    reviewRegistrationId = null;
    document.getElementById('reviewModal').classList.remove('active');
}

// Voter ID Generation Modal
function openVoterIdModal(registrationId) {
    reviewRegistrationId = registrationId;
    
    // Generate a voter ID
    const count = Object.keys(window.appUtils.getRegisteredUsers()).length + 1;
    const voterId = `VID-2025-${String(count).padStart(6, '0')}`;
    
    document.getElementById('generatedVoterId').value = voterId;
    document.getElementById('voterIdModal').classList.add('active');
}

function closeVoterIdModal() {
    reviewRegistrationId = null;
    document.getElementById('voterIdModal').classList.remove('active');
}

function confirmApproval() {
    if (!reviewRegistrationId) return;
    
    const voterId = document.getElementById('generatedVoterId').value;
    if (!voterId) {
        window.appUtils.showToast('Please enter a voter ID', 'error');
        return;
    }
    
    approveRegistrationWithId(reviewRegistrationId, voterId);
    closeVoterIdModal();
}

function approveRegistrationWithId(registrationId, voterId) {
    const registrations = window.appUtils.getPendingRegistrations();
    const registration = registrations.find(r => r.id === registrationId);
    
    if (!registration) return;
    
    // Update registration status
    registration.status = 'approved';
    registration.generatedVoterId = voterId;
    window.appUtils.setPendingRegistrations(registrations);
    
    // Add to registered users
    const users = window.appUtils.getRegisteredUsers();
    users[registration.email] = {
        facePhoto: registration.facePhoto,
        voterId: voterId,
        password: registration.password
    };
    window.appUtils.setRegisteredUsers(users);
    
    window.appUtils.showToast('Registration approved! Voter ID generated.', 'success');
    renderRegistrations();
    
    // In a real application, this would send an email to the user
    console.log(`Voter ID ${voterId} generated for ${registration.email}`);
}

function rejectRegistrationPrompt(registrationId) {
    if (confirm('Are you sure you want to reject this registration?')) {
        const registrations = window.appUtils.getPendingRegistrations();
        const registration = registrations.find(r => r.id === registrationId);
        
        if (registration) {
            registration.status = 'rejected';
            window.appUtils.setPendingRegistrations(registrations);
            window.appUtils.showToast('Registration rejected', 'info');
            renderRegistrations();
        }
    }
}

function rejectRegistration() {
    if (!reviewRegistrationId) return;
    
    rejectRegistrationPrompt(reviewRegistrationId);
    closeReviewModal();
}

function approveRegistration() {
    if (!reviewRegistrationId) return;
    
    closeReviewModal();
    openVoterIdModal(reviewRegistrationId);
}

// View Voter ID
function viewVoterID(registrationId) {
    const registrations = window.appUtils.getPendingRegistrations();
    const registration = registrations.find(r => r.id === registrationId);
    
    if (registration && registration.generatedVoterId) {
        // Create and display voter ID card
        displayVoterIDCard(registration);
    }
}

function displayVoterIDCard(registration) {
    // This would open a new page or modal with the voter ID card
    // For now, we'll show an alert
    alert(`Voter ID Card\n\nName: ${registration.name}\nVoter ID: ${registration.generatedVoterId}\nEmail: ${registration.email}`);
}

// Face & QR Demo
function startFaceDemo() {
    window.appUtils.showToast('Face recognition demo would start here', 'info');
}

function startQRDemo() {
    window.appUtils.showToast('QR code scanner demo would start here', 'info');
}

// Close modals when clicking outside
window.addEventListener('click', (event) => {
    const deleteModal = document.getElementById('deleteModal');
    const reviewModal = document.getElementById('reviewModal');
    const voterIdModal = document.getElementById('voterIdModal');
    
    if (event.target === deleteModal) closeDeleteModal();
    if (event.target === reviewModal) closeReviewModal();
    if (event.target === voterIdModal) closeVoterIdModal();
});
