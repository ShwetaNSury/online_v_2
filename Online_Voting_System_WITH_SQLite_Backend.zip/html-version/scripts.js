// ==================== DATA STORAGE ====================
// Initialize localStorage with default data if not exists
function initializeData() {
    if (!localStorage.getItem('elections')) {
        const initialElections = [
            {
                id: "1",
                title: "2025 Student Council President",
                description: "Vote for your next student council president to represent the student body",
                candidates: [
                    { id: "1a", name: "Sarah Johnson", party: "Unity Party", votes: 342 },
                    { id: "1b", name: "Michael Chen", party: "Progress Coalition", votes: 298 },
                    { id: "1c", name: "Emily Rodriguez", party: "Student First", votes: 267 }
                ],
                startDate: "2025-01-01T00:00:00",
                endDate: "2025-01-15T23:59:59",
                totalVotes: 907,
                status: "active",
                eligibleVoters: 1500
            },
            {
                id: "2",
                title: "Class Representative Election",
                description: "Choose your class representative for the academic year 2025",
                candidates: [
                    { id: "2a", name: "David Kim", party: "Independent", votes: 156 },
                    { id: "2b", name: "Jessica Martinez", party: "Student Voice", votes: 189 },
                    { id: "2c", name: "James Wilson", party: "Independent", votes: 134 }
                ],
                startDate: "2025-01-05T00:00:00",
                endDate: "2025-01-20T23:59:59",
                totalVotes: 479,
                status: "active",
                eligibleVoters: 800
            },
            {
                id: "3",
                title: "University Senate Election",
                description: "Elect faculty and student representatives to the university senate",
                candidates: [
                    { id: "3a", name: "Dr. Robert Brown", party: "Academic Excellence", votes: 523 },
                    { id: "3b", name: "Prof. Linda Davis", party: "Innovation Alliance", votes: 467 },
                    { id: "3c", name: "Alex Thompson", party: "Student Coalition", votes: 412 },
                    { id: "3d", name: "Maria Garcia", party: "Independent", votes: 389 }
                ],
                startDate: "2024-12-20T00:00:00",
                endDate: "2025-01-10T23:59:59",
                totalVotes: 1791,
                status: "active",
                eligibleVoters: 2500
            }
        ];
        localStorage.setItem('elections', JSON.stringify(initialElections));
    }

    if (!localStorage.getItem('registeredUsers')) {
        const initialUsers = {
            "test.voter@example.com": {
                facePhoto: generateSampleFacePhoto('#f59e0b', '#d97706', 'TEST VOTER'),
                voterId: "VID-2025-000001",
                password: "password123"
            },
            "demo.user@example.com": {
                facePhoto: generateSampleFacePhoto('#8b5cf6', '#7c3aed', 'DEMO USER'),
                voterId: "VID-2025-000002",
                password: "password123"
            }
        };
        localStorage.setItem('registeredUsers', JSON.stringify(initialUsers));
    }

    if (!localStorage.getItem('pendingRegistrations')) {
        const initialPendingRegistrations = [
            {
                id: "sample1",
                name: "John Smith",
                email: "john.smith@example.com",
                password: "password123",
                phone: "+1 555-0101",
                dateOfBirth: "1990-05-15",
                address: "123 Main Street, Springfield, IL 62701",
                facePhoto: generateSampleFacePhoto('#3b82f6', '#1e40af', 'JOHN SMITH'),
                voterIdDocument: generateSampleIDDocument(),
                status: "pending",
                registrationDate: "December 28, 2024"
            },
            {
                id: "sample2",
                name: "Sarah Johnson",
                email: "sarah.johnson@example.com",
                password: "password123",
                phone: "+1 555-0102",
                dateOfBirth: "1985-08-22",
                address: "456 Oak Avenue, Chicago, IL 60601",
                facePhoto: generateSampleFacePhoto('#ec4899', '#be185d', 'SARAH JOHNSON'),
                voterIdDocument: generateSampleIDDocument(),
                status: "pending",
                registrationDate: "December 29, 2024"
            },
            {
                id: "sample3",
                name: "Michael Brown",
                email: "michael.brown@example.com",
                password: "password123",
                phone: "+1 555-0103",
                dateOfBirth: "1992-11-10",
                address: "789 Pine Road, Boston, MA 02101",
                facePhoto: generateSampleFacePhoto('#10b981', '#059669', 'MICHAEL BROWN'),
                voterIdDocument: generateSampleIDDocument(),
                status: "pending",
                registrationDate: "December 30, 2024"
            }
        ];
        localStorage.setItem('pendingRegistrations', JSON.stringify(initialPendingRegistrations));
    }

    if (!localStorage.getItem('votedElections')) {
        localStorage.setItem('votedElections', JSON.stringify({}));
    }
}

// Data getters and setters
function getElections() {
    return JSON.parse(localStorage.getItem('elections') || '[]');
}

function setElections(elections) {
    localStorage.setItem('elections', JSON.stringify(elections));
}

function getRegisteredUsers() {
    return JSON.parse(localStorage.getItem('registeredUsers') || '{}');
}

function setRegisteredUsers(users) {
    localStorage.setItem('registeredUsers', JSON.stringify(users));
}

function getPendingRegistrations() {
    return JSON.parse(localStorage.getItem('pendingRegistrations') || '[]');
}

function setPendingRegistrations(registrations) {
    localStorage.setItem('pendingRegistrations', JSON.stringify(registrations));
}

function getVotedElections() {
    return JSON.parse(localStorage.getItem('votedElections') || '{}');
}

function setVotedElections(voted) {
    localStorage.setItem('votedElections', JSON.stringify(voted));
}

function getCurrentUser() {
    return JSON.parse(localStorage.getItem('currentUser') || 'null');
}

function setCurrentUser(user) {
    if (user) {
        localStorage.setItem('currentUser', JSON.stringify(user));
    } else {
        localStorage.removeItem('currentUser');
    }
}

// ==================== SAMPLE DATA GENERATORS ====================
function generateSampleFacePhoto(colorStart, colorEnd, label) {
    const canvas = document.createElement('canvas');
    canvas.width = 640;
    canvas.height = 480;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
        // Background gradient
        const gradient = ctx.createLinearGradient(0, 0, 0, 480);
        gradient.addColorStop(0, colorStart);
        gradient.addColorStop(1, colorEnd);
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, 640, 480);
        
        // Face circle
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(320, 200, 80, 0, Math.PI * 2);
        ctx.fill();
        
        // Eyes
        ctx.fillStyle = colorStart;
        ctx.beginPath();
        ctx.arc(295, 190, 12, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(345, 190, 12, 0, Math.PI * 2);
        ctx.fill();
        
        // Smile
        ctx.strokeStyle = colorStart;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(320, 210, 25, 0.2, Math.PI - 0.2);
        ctx.stroke();
        
        // Body
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(250, 280, 140, 200);
        
        // Text
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 20px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(label, 320, 420);
        ctx.font = '14px Arial';
        ctx.fillText('Sample Voter Photo', 320, 445);
        
        return canvas.toDataURL('image/jpeg');
    }
    return '';
}

function generateSampleIDDocument() {
    const canvas = document.createElement('canvas');
    canvas.width = 800;
    canvas.height = 500;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
        // Background
        ctx.fillStyle = '#f3f4f6';
        ctx.fillRect(0, 0, 800, 500);
        
        // Border
        ctx.strokeStyle = '#3b82f6';
        ctx.lineWidth = 8;
        ctx.strokeRect(20, 20, 760, 460);
        
        // Title
        ctx.fillStyle = '#1e40af';
        ctx.font = 'bold 32px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('GOVERNMENT ISSUED ID', 400, 80);
        
        // Sample text
        ctx.fillStyle = '#374151';
        ctx.font = '20px Arial';
        ctx.textAlign = 'left';
        ctx.fillText('ID Number: SAMPLE-2025-001', 60, 150);
        ctx.fillText('Full Name: Sample User', 60, 200);
        ctx.fillText('Date of Birth: 01/01/1990', 60, 250);
        ctx.fillText('Address: 123 Sample Street', 60, 300);
        
        // Watermark
        ctx.fillStyle = '#9ca3af';
        ctx.font = 'bold 48px Arial';
        ctx.textAlign = 'center';
        ctx.globalAlpha = 0.3;
        ctx.fillText('SAMPLE DOCUMENT', 400, 400);
        ctx.fillText('FOR TESTING ONLY', 400, 450);
        
        return canvas.toDataURL('image/jpeg');
    }
    return '';
}

// ==================== AUTHENTICATION ====================
function logout() {
    setCurrentUser(null);
    setVotedElections({});
    showToast('Logged out successfully', 'success');
    setTimeout(() => {
        window.location.href = 'index.html';
    }, 500);
}

function checkAuth() {
    const user = getCurrentUser();
    if (user) {
        updateHeaderForUser(user);
    }
    return user;
}

function updateHeaderForUser(user) {
    const authButtons = document.getElementById('authButtons');
    const userMenu = document.getElementById('userMenu');
    
    if (authButtons && userMenu) {
        authButtons.style.display = 'none';
        userMenu.style.display = 'flex';
        const userName = document.getElementById('userName');
        if (userName) {
            userName.textContent = user.name || user.email.split('@')[0];
        }
    }
}

// ==================== TOAST NOTIFICATIONS ====================
function showToast(message, type = 'info') {
    // Remove existing toasts
    const existingToasts = document.querySelectorAll('.toast');
    existingToasts.forEach(toast => toast.remove());
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    
    // Styling
    const styles = {
        position: 'fixed',
        top: '20px',
        right: '20px',
        padding: '1rem 1.5rem',
        borderRadius: '0.5rem',
        color: 'white',
        fontWeight: '500',
        zIndex: '10000',
        animation: 'slideIn 0.3s ease-out',
        boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)'
    };
    
    Object.assign(toast.style, styles);
    
    // Set background color based on type
    const colors = {
        success: '#10b981',
        error: '#ef4444',
        warning: '#f59e0b',
        info: '#3b82f6'
    };
    toast.style.backgroundColor = colors[type] || colors.info;
    
    document.body.appendChild(toast);
    
    // Remove after 3 seconds
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Add CSS animations for toast
if (!document.getElementById('toast-animations')) {
    const style = document.createElement('style');
    style.id = 'toast-animations';
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
}

// ==================== UTILITY FUNCTIONS ====================
function scrollToElections() {
    const electionsSection = document.getElementById('elections');
    if (electionsSection) {
        electionsSection.scrollIntoView({ behavior: 'smooth' });
    }
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
    });
}

function calculatePercentage(votes, total) {
    if (total === 0) return 0;
    return ((votes / total) * 100).toFixed(1);
}

function getElectionStatus(election) {
    const now = new Date();
    const startDate = new Date(election.startDate);
    const endDate = new Date(election.endDate);
    
    if (now < startDate) return 'upcoming';
    if (now > endDate) return 'closed';
    return 'active';
}

// ==================== TABS FUNCTIONALITY ====================
function initializeTabs() {
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const tab = button.getAttribute('data-tab');
            
            // Remove active class from all buttons and contents
            document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            
            // Add active class to clicked button and corresponding content
            button.classList.add('active');
            const content = document.getElementById(`${tab}-content`);
            if (content) {
                content.classList.add('active');
            }
        });
    });
}

// ==================== INITIALIZE APP ====================
document.addEventListener('DOMContentLoaded', () => {
    initializeData();
    checkAuth();
    initializeTabs();
});

// Export functions for use in other scripts
window.appUtils = {
    getElections,
    setElections,
    getRegisteredUsers,
    setRegisteredUsers,
    getPendingRegistrations,
    setPendingRegistrations,
    getVotedElections,
    setVotedElections,
    getCurrentUser,
    setCurrentUser,
    generateSampleFacePhoto,
    generateSampleIDDocument,
    showToast,
    formatDate,
    calculatePercentage,
    getElectionStatus,
    logout,
    checkAuth,
    scrollToElections
};
