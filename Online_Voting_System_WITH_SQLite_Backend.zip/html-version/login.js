// Login functionality
let loginFormData = {};
let faceStream = null;
let qrStream = null;
let qrScanInterval = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initializeAuthTabs();
    initializeLoginForm();
    generateSampleQRCodes();
});

// Auth tabs
function initializeAuthTabs() {
    const tabButtons = document.querySelectorAll('.auth-tab-btn');
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const tab = button.getAttribute('data-tab');
            
            // Stop any active streams
            stopFaceStream();
            stopQRScan();
            
            // Switch tabs
            document.querySelectorAll('.auth-tab-btn').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.auth-tab-content').forEach(content => content.classList.remove('active'));
            
            button.classList.add('active');
            document.getElementById(`${tab}-tab`).classList.add('active');
        });
    });
}

// Login form
function initializeLoginForm() {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLoginSubmit);
    }
}

function handleLoginSubmit(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;
    
    // Check admin credentials
    if (role === 'admin') {
        if (email === 'admin@election.com' && password === 'admin123') {
            const adminUser = {
                name: 'Admin User',
                email: 'admin@election.com',
                role: 'admin'
            };
            window.appUtils.setCurrentUser(adminUser);
            window.appUtils.showToast('Welcome Admin!', 'success');
            setTimeout(() => {
                window.location.href = 'admin.html';
            }, 500);
        } else {
            window.appUtils.showToast('Invalid admin credentials', 'error');
        }
        return;
    }
    
    // Check voter credentials
    const users = window.appUtils.getRegisteredUsers();
    const userData = users[email];
    
    if (!userData) {
        window.appUtils.showToast('User not found. Please register first or wait for admin approval.', 'error');
        return;
    }
    
    if (userData.password !== password) {
        window.appUtils.showToast('Invalid password', 'error');
        return;
    }
    
    // Store login data and proceed to face verification
    loginFormData = {
        email,
        password,
        role,
        userData
    };
    
    openFaceVerificationModal();
}

// Face Verification Modal
function openFaceVerificationModal() {
    const modal = document.getElementById('faceVerificationModal');
    modal.classList.add('active');
    startFaceCapture();
}

function closeFaceVerification() {
    const modal = document.getElementById('faceVerificationModal');
    modal.classList.remove('active');
    stopFaceStream();
    loginFormData = {};
}

function startFaceCapture() {
    const video = document.getElementById('faceVideo');
    
    navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => {
            faceStream = stream;
            video.srcObject = stream;
        })
        .catch(err => {
            console.error('Error accessing camera:', err);
            window.appUtils.showToast('Camera access denied. You can use sample photo for testing.', 'warning');
        });
}

function stopFaceStream() {
    if (faceStream) {
        faceStream.getTracks().forEach(track => track.stop());
        faceStream = null;
    }
}

function captureFace() {
    const video = document.getElementById('faceVideo');
    const canvas = document.getElementById('faceCanvas');
    const capturedPhotoContainer = document.getElementById('capturedPhotoContainer');
    const capturedPhoto = document.getElementById('capturedPhoto');
    const cameraContainer = document.getElementById('cameraContainer');
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0);
    
    const photoData = canvas.toDataURL('image/jpeg');
    capturedPhoto.src = photoData;
    
    // Show captured photo, hide video
    cameraContainer.style.display = 'none';
    capturedPhotoContainer.style.display = 'block';
    
    // Update buttons
    document.getElementById('captureFaceBtn').style.display = 'none';
    document.getElementById('retakeFaceBtn').style.display = 'inline-flex';
    document.getElementById('verifyFaceBtn').disabled = false;
    
    stopFaceStream();
}

function retakeFace() {
    const cameraContainer = document.getElementById('cameraContainer');
    const capturedPhotoContainer = document.getElementById('capturedPhotoContainer');
    
    cameraContainer.style.display = 'block';
    capturedPhotoContainer.style.display = 'none';
    
    document.getElementById('captureFaceBtn').style.display = 'inline-flex';
    document.getElementById('retakeFaceBtn').style.display = 'none';
    document.getElementById('verifyFaceBtn').disabled = true;
    
    startFaceCapture();
}

function useSamplePhoto(index) {
    const colors = [
        ['#f59e0b', '#d97706'],
        ['#8b5cf6', '#7c3aed']
    ];
    const labels = ['SAMPLE USER 1', 'SAMPLE USER 2'];
    
    const photoData = window.appUtils.generateSampleFacePhoto(colors[index - 1][0], colors[index - 1][1], labels[index - 1]);
    
    const capturedPhoto = document.getElementById('capturedPhoto');
    const capturedPhotoContainer = document.getElementById('capturedPhotoContainer');
    const cameraContainer = document.getElementById('cameraContainer');
    
    capturedPhoto.src = photoData;
    cameraContainer.style.display = 'none';
    capturedPhotoContainer.style.display = 'block';
    
    document.getElementById('captureFaceBtn').style.display = 'none';
    document.getElementById('retakeFaceBtn').style.display = 'inline-flex';
    document.getElementById('verifyFaceBtn').disabled = false;
    
    stopFaceStream();
}

function verifyFace() {
    // In a real application, this would perform actual face verification
    // For demo purposes, we'll simulate successful verification
    
    window.appUtils.showToast('Face verification successful!', 'success');
    
    // Complete login
    const user = {
        name: loginFormData.email.split('@')[0],
        email: loginFormData.email,
        role: 'voter',
        voterId: loginFormData.userData.voterId
    };
    
    window.appUtils.setCurrentUser(user);
    
    setTimeout(() => {
        window.location.href = 'index.html';
    }, 500);
}

// QR Code Scanner
function generateSampleQRCodes() {
    const users = window.appUtils.getRegisteredUsers();
    const userEmails = Object.keys(users);
    
    if (userEmails.length >= 2) {
        // Generate QR codes for sample users
        try {
            new QRCode(document.getElementById('sampleQR1'), {
                text: JSON.stringify({ email: userEmails[0], voterId: users[userEmails[0]].voterId }),
                width: 120,
                height: 120
            });
            
            new QRCode(document.getElementById('sampleQR2'), {
                text: JSON.stringify({ email: userEmails[1], voterId: users[userEmails[1]].voterId }),
                width: 120,
                height: 120
            });
        } catch (error) {
            console.error('Error generating QR codes:', error);
        }
    }
}

function startQRScan() {
    const video = document.getElementById('qrVideo');
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    
    document.getElementById('startQRScanBtn').style.display = 'none';
    document.getElementById('stopQRScanBtn').style.display = 'inline-flex';
    
    navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
        .then(stream => {
            qrStream = stream;
            video.srcObject = stream;
            video.play();
            
            // Start scanning
            qrScanInterval = setInterval(() => {
                if (video.readyState === video.HAVE_ENOUGH_DATA) {
                    canvas.width = video.videoWidth;
                    canvas.height = video.videoHeight;
                    context.drawImage(video, 0, 0, canvas.width, canvas.height);
                    
                    const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
                    const code = jsQR(imageData.data, imageData.width, imageData.height);
                    
                    if (code) {
                        handleQRCodeScan(code.data);
                    }
                }
            }, 100);
        })
        .catch(err => {
            console.error('Error accessing camera:', err);
            window.appUtils.showToast('Camera access denied. You can use sample QR codes for testing.', 'warning');
            document.getElementById('startQRScanBtn').style.display = 'inline-flex';
            document.getElementById('stopQRScanBtn').style.display = 'none';
        });
}

function stopQRScan() {
    if (qrStream) {
        qrStream.getTracks().forEach(track => track.stop());
        qrStream = null;
    }
    
    if (qrScanInterval) {
        clearInterval(qrScanInterval);
        qrScanInterval = null;
    }
    
    document.getElementById('startQRScanBtn').style.display = 'inline-flex';
    document.getElementById('stopQRScanBtn').style.display = 'none';
}

function handleQRCodeScan(data) {
    try {
        const qrData = JSON.parse(data);
        const users = window.appUtils.getRegisteredUsers();
        const userData = users[qrData.email];
        
        if (userData && userData.voterId === qrData.voterId) {
            stopQRScan();
            loginWithQR(qrData.email, userData);
        }
    } catch (error) {
        console.error('Invalid QR code:', error);
    }
}

function useSampleQR(email) {
    const users = window.appUtils.getRegisteredUsers();
    const userData = users[email];
    
    if (userData) {
        loginWithQR(email, userData);
    }
}

function loginWithQR(email, userData) {
    window.appUtils.showToast('QR code verified successfully!', 'success');
    
    const user = {
        name: email.split('@')[0],
        email: email,
        role: 'voter',
        voterId: userData.voterId
    };
    
    window.appUtils.setCurrentUser(user);
    
    setTimeout(() => {
        window.location.href = 'index.html';
    }, 500);
}

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    stopFaceStream();
    stopQRScan();
});
