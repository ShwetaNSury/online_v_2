# Election Voting System - HTML/CSS/JavaScript Version

A complete election voting system built with pure HTML, CSS, and vanilla JavaScript. This is a standalone version that mirrors all the features of the React application.

## Features

### Voter Portal
- **Election Browsing**: View active, upcoming, and closed elections
- **Search Functionality**: Search elections by title or description
- **Secure Voting**: Cast votes with duplicate prevention
- **Results Viewing**: Real-time visualization of election results with charts
- **Face Recognition Login**: Biometric authentication for secure access
- **QR Code Authentication**: Quick login using voter ID QR codes

### Admin Portal
- **Dashboard Overview**: Statistics and recent activity
- **Election Management**: Create, view, edit, and delete elections
- **Voter Registration Management**: Review and approve voter registrations
- **Voter ID Generation**: Automatic generation of unique voter IDs
- **Face & QR System Demo**: Test authentication methods

### Voter Registration
- **Multi-Step Form**: Personal information, face capture, ID upload, and review
- **Face Capture**: Camera-based photo capture with sample options
- **ID Document Upload**: Drag-and-drop or file selection with preview
- **Admin Approval**: Pending registrations reviewed by administrators

### Security Features
- **Face Recognition**: Biometric authentication during login
- **QR Code Scanning**: Secure QR code-based authentication
- **Duplicate Vote Prevention**: Users can only vote once per election
- **Role-Based Access**: Separate portals for voters and administrators

## File Structure

```
html-version/
├── index.html              # Voter portal homepage
├── admin.html              # Admin dashboard
├── login.html              # Login page with face/QR authentication
├── register.html           # Voter registration form
├── results.html            # Election results page with charts
├── styles.css              # Complete styling for all pages
├── scripts.js              # Core utilities and data management
├── voter-portal.js         # Voter portal functionality
├── login.js                # Login and authentication logic
├── register.js             # Registration form logic
├── admin-portal.js         # Admin dashboard functionality
├── results.js              # Results visualization with Chart.js
└── README.md               # This file
```

## Getting Started

### 1. Open the Application
Simply open `index.html` in a modern web browser (Chrome, Firefox, Edge, or Safari).

### 2. Test Accounts

#### Admin Account
- **Email**: `admin@election.com`
- **Password**: `admin123`
- **Role**: Administrator

#### Voter Accounts
- **Email**: `test.voter@example.com`
- **Password**: `password123`
- **Voter ID**: `VID-2025-000001`

- **Email**: `demo.user@example.com`
- **Password**: `password123`
- **Voter ID**: `VID-2025-000002`

### 3. Sample Data
The application comes pre-loaded with:
- 3 sample elections
- 2 pre-approved voters
- 3 pending voter registrations
- Sample face photos and ID documents for testing

## How to Use

### As a Voter

1. **Register**
   - Click "Register" on the homepage
   - Fill in personal information
   - Capture your photo (or use sample photo)
   - Upload ID document (or use sample document)
   - Review and submit
   - Wait for admin approval

2. **Login**
   - Click "Login" on the homepage
   - Enter email and password
   - Complete face verification
   - Or use QR code scanner

3. **Vote**
   - Browse active elections
   - Click "Vote Now"
   - Select your preferred candidate
   - Submit your vote

4. **View Results**
   - Click "Results" on any election card
   - View detailed statistics and charts
   - Export results as CSV

### As an Administrator

1. **Login**
   - Go to login page
   - Select "Administrator" role
   - Use admin credentials

2. **View Dashboard**
   - See overview of all elections
   - Monitor voter turnout
   - Review recent activity

3. **Create Election**
   - Navigate to "Create Election" tab
   - Fill in election details
   - Add candidates
   - Set start and end dates
   - Submit to create

4. **Manage Elections**
   - View all elections
   - Delete elections if needed
   - View detailed results

5. **Approve Voters**
   - Navigate to "Voter Registration" tab
   - Review pending registrations
   - View uploaded documents
   - Generate voter ID
   - Approve or reject registrations

## Features in Detail

### Face Recognition
- Uses browser's camera API
- Captures photo during registration
- Verifies face during login
- Sample photos available for testing

### QR Code Authentication
- Each voter receives a unique QR code
- Scan QR code to login instantly
- Works with both camera and sample QRs
- Secure voter ID verification

### Election Management
- Create elections with multiple candidates
- Set voting period (start/end dates)
- Track voter turnout in real-time
- Automatic status updates (upcoming/active/closed)

### Voting System
- One vote per election per user
- Vote stored securely in browser
- Real-time vote count updates
- Cannot change vote after submission

### Results Visualization
- Bar chart showing vote distribution
- Pie chart showing vote percentages
- Timeline chart showing vote progression
- Detailed candidate statistics
- Export results to CSV

### Data Persistence
All data is stored in browser's localStorage:
- Elections and votes
- User accounts and registrations
- Voted elections tracking
- Session management

## Browser Compatibility

- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+

## Camera Permissions

For face recognition and QR scanning:
1. Browser will request camera access
2. Allow camera permissions
3. Or use sample photos/QR codes for testing

## Dependencies

The application uses the following CDN libraries:
- **Font Awesome 6.4.0** - Icons
- **Chart.js** - Charts and graphs
- **QRCode.js** - QR code generation
- **jsQR** - QR code scanning

All dependencies are loaded via CDN, no installation required.

## Testing Features

### Without Camera Access
- Use "Sample Photo" buttons during registration
- Use "Sample QR Code" buttons during login
- Use "Sample ID Document" button for ID upload

### Complete Testing Flow
1. Register a new voter with sample data
2. Login as admin
3. Approve the registration
4. Logout from admin
5. Login as the newly approved voter
6. Vote in an election
7. View results with charts

## Data Reset

To reset all data:
1. Open browser console (F12)
2. Run: `localStorage.clear()`
3. Refresh the page

## Customization

### Colors
Edit CSS variables in `styles.css`:
```css
:root {
    --primary-color: #2563eb;
    --secondary-color: #64748b;
    --success-color: #10b981;
    --danger-color: #ef4444;
    /* ... */
}
```

### Sample Elections
Edit initial elections in `scripts.js`:
```javascript
const initialElections = [ /* ... */ ];
```

## Known Limitations

1. **Data Storage**: Uses localStorage (limited to ~5-10MB)
2. **Camera Access**: Requires HTTPS in production
3. **Single User Session**: One user logged in at a time
4. **No Backend**: All data stored in browser

## Production Deployment

For production use:
1. Host on HTTPS server (required for camera access)
2. Replace sample data with empty arrays
3. Integrate with actual backend API
4. Implement real face recognition algorithm
5. Add email notifications for approvals
6. Add database for persistent storage

## Security Notes

⚠️ **Important**: This is a demonstration application
- Face verification is simulated
- Data is stored in browser (not secure for production)
- Passwords are stored in plain text
- No server-side validation
- Not suitable for real elections without proper backend

For production elections, implement:
- Real biometric authentication
- Server-side data storage and encryption
- Blockchain or cryptographic vote verification
- Multi-factor authentication
- Audit trails and logging

## Support

For issues or questions about this HTML version:
1. Check browser console for errors
2. Verify camera permissions
3. Try using sample data for testing
4. Clear localStorage and refresh

## License

This is a demonstration project for educational purposes.

---

**Built with ❤️ using pure HTML, CSS, and JavaScript**
