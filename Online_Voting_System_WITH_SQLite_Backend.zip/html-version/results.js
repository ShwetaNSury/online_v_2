// Results Page functionality
let currentElection = null;
let barChart = null;
let pieChart = null;
let lineChart = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadElectionResults();
});

function loadElectionResults() {
    // Get election ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const electionId = urlParams.get('id');
    
    if (!electionId) {
        window.appUtils.showToast('No election selected', 'error');
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 1000);
        return;
    }
    
    const elections = window.appUtils.getElections();
    currentElection = elections.find(e => e.id === electionId);
    
    if (!currentElection) {
        window.appUtils.showToast('Election not found', 'error');
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 1000);
        return;
    }
    
    renderElectionInfo();
    renderStatistics();
    renderCandidateResults();
    renderCharts();
}

function renderElectionInfo() {
    document.getElementById('electionTitle').textContent = currentElection.title;
    document.getElementById('electionDescription').textContent = currentElection.description;
    
    const status = window.appUtils.getElectionStatus(currentElection);
    const statusBadge = document.getElementById('electionStatus');
    statusBadge.textContent = status.charAt(0).toUpperCase() + status.slice(1);
    statusBadge.style.backgroundColor = getStatusColor(status);
    
    document.getElementById('electionDates').textContent = 
        `${window.appUtils.formatDate(currentElection.startDate)} - ${window.appUtils.formatDate(currentElection.endDate)}`;
}

function getStatusColor(status) {
    const colors = {
        active: '#10b981',
        upcoming: '#f59e0b',
        closed: '#6b7280'
    };
    return colors[status] || '#6b7280';
}

function renderStatistics() {
    const turnoutPercentage = window.appUtils.calculatePercentage(
        currentElection.totalVotes,
        currentElection.eligibleVoters
    );
    
    const leadingCandidate = [...currentElection.candidates]
        .sort((a, b) => b.votes - a.votes)[0];
    
    document.getElementById('totalVotesCount').textContent = currentElection.totalVotes.toLocaleString();
    document.getElementById('eligibleVotersCount').textContent = currentElection.eligibleVoters.toLocaleString();
    document.getElementById('turnoutPercentage').textContent = `${turnoutPercentage}%`;
    document.getElementById('leadingCandidate').textContent = leadingCandidate.name;
}

function renderCandidateResults() {
    const sortedCandidates = [...currentElection.candidates]
        .sort((a, b) => b.votes - a.votes);
    
    const totalVotes = currentElection.totalVotes || 1; // Avoid division by zero
    const maxVotes = sortedCandidates[0]?.votes || 0;
    
    const container = document.getElementById('candidatesList');
    container.innerHTML = sortedCandidates.map((candidate, index) => {
        const percentage = window.appUtils.calculatePercentage(candidate.votes, totalVotes);
        const barWidth = totalVotes > 0 ? (candidate.votes / maxVotes * 100) : 0;
        const isWinner = index === 0 && candidate.votes > 0;
        
        return `
            <div class="candidate-result ${isWinner ? 'winner' : ''}">
                <div class="candidate-result-header">
                    <div>
                        <h4>${candidate.name}</h4>
                        <p style="color: #6b7280; margin: 0;">${candidate.party}</p>
                    </div>
                    ${isWinner ? `
                        <span class="winner-badge">
                            <i class="fas fa-trophy"></i> Winner
                        </span>
                    ` : ''}
                </div>
                <div class="candidate-result-body">
                    <div class="vote-info">
                        <div class="vote-stat">
                            <strong>${candidate.votes}</strong>
                            <span>Votes</span>
                        </div>
                        <div class="vote-stat">
                            <strong>${percentage}%</strong>
                            <span>Vote Share</span>
                        </div>
                    </div>
                    <div class="vote-bar-container">
                        <div class="vote-bar" style="width: ${barWidth}%">
                            ${barWidth > 20 ? percentage + '%' : ''}
                        </div>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

function renderCharts() {
    const candidates = currentElection.candidates;
    const labels = candidates.map(c => c.name);
    const votes = candidates.map(c => c.votes);
    const colors = [
        '#3b82f6',
        '#10b981',
        '#f59e0b',
        '#ef4444',
        '#8b5cf6',
        '#ec4899'
    ];
    
    // Bar Chart
    const barCtx = document.getElementById('barChart').getContext('2d');
    if (barChart) barChart.destroy();
    barChart = new Chart(barCtx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Votes',
                data: votes,
                backgroundColor: colors.slice(0, candidates.length),
                borderColor: colors.slice(0, candidates.length),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `Votes: ${context.parsed.y}`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });
    
    // Pie Chart
    const pieCtx = document.getElementById('pieChart').getContext('2d');
    if (pieChart) pieChart.destroy();
    pieChart = new Chart(pieCtx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: votes,
                backgroundColor: colors.slice(0, candidates.length),
                borderColor: '#ffffff',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((context.parsed / total) * 100).toFixed(1);
                            return `${context.label}: ${context.parsed} votes (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
    
    // Line Chart (Vote Timeline)
    const lineCtx = document.getElementById('lineChart').getContext('2d');
    if (lineChart) lineChart.destroy();
    
    // Generate mock timeline data
    const timelineData = generateMockTimeline();
    
    lineChart = new Chart(lineCtx, {
        type: 'line',
        data: {
            labels: timelineData.labels,
            datasets: candidates.map((candidate, index) => ({
                label: candidate.name,
                data: timelineData.data[index],
                borderColor: colors[index],
                backgroundColor: colors[index] + '20',
                tension: 0.4,
                fill: false
            }))
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom'
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });
}

function generateMockTimeline() {
    const candidates = currentElection.candidates;
    const timePoints = 10;
    const labels = [];
    const data = candidates.map(() => []);
    
    // Generate time labels
    const start = new Date(currentElection.startDate);
    const end = new Date(currentElection.endDate);
    const duration = end - start;
    
    for (let i = 0; i <= timePoints; i++) {
        const time = new Date(start.getTime() + (duration / timePoints) * i);
        labels.push(time.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
    }
    
    // Generate cumulative vote data
    candidates.forEach((candidate, candidateIndex) => {
        let cumulativeVotes = 0;
        for (let i = 0; i <= timePoints; i++) {
            const progress = i / timePoints;
            const votesAtTime = Math.floor(candidate.votes * progress);
            data[candidateIndex].push(votesAtTime);
        }
    });
    
    return { labels, data };
}

function goBack() {
    window.history.back();
}

function exportResults() {
    // Generate CSV content
    let csv = 'Candidate,Party,Votes,Percentage\n';
    
    const totalVotes = currentElection.totalVotes || 1;
    currentElection.candidates.forEach(candidate => {
        const percentage = window.appUtils.calculatePercentage(candidate.votes, totalVotes);
        csv += `"${candidate.name}","${candidate.party}",${candidate.votes},${percentage}%\n`;
    });
    
    // Create download link
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentElection.title.replace(/\s+/g, '_')}_results.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    window.appUtils.showToast('Results exported successfully!', 'success');
}
