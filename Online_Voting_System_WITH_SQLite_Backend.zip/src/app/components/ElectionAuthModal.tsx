import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { toast } from "sonner";
import { Camera, FileText } from "lucide-react";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (email: string, password: string) => void;
  onSignupClick: () => void;
  onLoginPageClick?: () => void;
  initialTab?: "login" | "signup";
}

export function ElectionAuthModal({ isOpen, onClose, onLogin, onSignupClick, onLoginPageClick, initialTab = "login" }: AuthModalProps) {
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail || !loginPassword) {
      toast.error("Please fill in all fields");
      return;
    }
    
    // Redirect to full login page if provided
    if (onLoginPageClick) {
      onClose();
      onLoginPageClick();
      return;
    }
    
    onLogin(loginEmail, loginPassword);
    setLoginEmail("");
    setLoginPassword("");
    onClose();
  };

  const handleSignupRedirect = () => {
    onClose();
    onSignupClick();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[450px]">
        <DialogHeader>
          <DialogTitle>Welcome to ElectionHub</DialogTitle>
          <DialogDescription>
            Login or register as a voter to participate in elections
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue={initialTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="login">Login</TabsTrigger>
            <TabsTrigger value="signup">Register</TabsTrigger>
          </TabsList>

          <TabsContent value="login">
            <form onSubmit={handleLogin} className="space-y-4 mt-4">
              <div>
                <Label htmlFor="login-email">Email or Voter ID</Label>
                <Input
                  id="login-email"
                  type="text"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  placeholder="your@email.com or V123456"
                  className="mt-2"
                  required
                />
              </div>
              <div>
                <Label htmlFor="login-password">Password</Label>
                <Input
                  id="login-password"
                  type="password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="•••••••"
                  className="mt-2"
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                Login
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="signup">
            <div className="space-y-4 mt-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Camera className="size-5 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-blue-900 mb-1">Enhanced Registration Process</h4>
                    <p className="text-sm text-blue-800 mb-3">
                      Our registration requires face verification and document upload for security. 
                      Please use the full registration form.
                    </p>
                    <ul className="text-sm text-blue-800 space-y-1 mb-4">
                      <li className="flex items-center gap-2">
                        <span className="text-blue-600">✓</span>
                        <span>Live face photo capture</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <span className="text-blue-600">✓</span>
                        <span>Voter ID document upload</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <span className="text-blue-600">✓</span>
                        <span>Admin approval process</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <Button onClick={handleSignupRedirect} className="w-full" size="lg">
                <FileText className="size-4 mr-2" />
                Go to Full Registration Form
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}