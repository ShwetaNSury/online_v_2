import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { toast } from "sonner";
import { Vote, ArrowLeft, Upload, Camera, CheckCircle } from "lucide-react";
import { FaceCapture } from "./FaceCapture";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";

interface RegisterPageProps {
  onRegister: (registrationData: {
    name: string;
    email: string;
    password: string;
    phone: string;
    dateOfBirth: string;
    address: string;
    facePhoto: string;
    voterIdDocument: string;
  }) => void;
  onNavigateToLogin: () => void;
}

export function RegisterPage({ onRegister, onNavigateToLogin }: RegisterPageProps) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [dateOfBirth, setDateOfBirth] = useState("");
  const [address, setAddress] = useState("");
  const [showFaceCapture, setShowFaceCapture] = useState(false);
  const [facePhoto, setFacePhoto] = useState<string | null>(null);
  const [voterIdDocument, setVoterIdDocument] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState(1);

  const handleVoterIdUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("File size must be less than 5MB");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      setVoterIdDocument(result);
      toast.success("Voter ID document uploaded successfully!");
    };
    reader.readAsDataURL(file);
  };

  const handleStep1Submit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name || !email || !password || !confirmPassword || !phone || !dateOfBirth || !address) {
      toast.error("Please fill in all required fields");
      return;
    }

    if (password !== confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }

    if (password.length < 6) {
      toast.error("Password must be at least 6 characters");
      return;
    }

    // Move to step 2 (document upload)
    setCurrentStep(2);
  };

  const handleStep2Submit = () => {
    if (!voterIdDocument) {
      toast.error("Please upload your Voter ID document");
      return;
    }

    // Move to step 3 (face capture)
    setShowFaceCapture(true);
  };

  const handleFaceCapture = (capturedPhoto: string) => {
    setFacePhoto(capturedPhoto);
    setShowFaceCapture(false);
    
    // Complete registration with all data
    onRegister({
      name,
      email,
      password,
      phone,
      dateOfBirth,
      address,
      facePhoto: capturedPhoto,
      voterIdDocument: voterIdDocument!,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8 px-4">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Vote className="size-10 text-blue-600" />
            <h1 className="text-3xl">Voter Registration</h1>
          </div>
          <p className="text-gray-600">Complete all steps to register as a voter</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Left side - Instructions */}
          <div className="md:col-span-1 space-y-4">
            <div className="bg-white rounded-lg p-6 shadow-lg">
              <h3 className="font-semibold mb-3">Registration Process:</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start gap-2">
                  <span className="text-blue-600">1.</span>
                  <span>Fill personal information & create password</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600">2.</span>
                  <span>Upload government-issued ID for verification</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600">3.</span>
                  <span>Capture live face photo (for login security)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600">4.</span>
                  <span>Admin reviews & generates your Voter ID</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Middle side - Registration Form */}
          <div className="md:col-span-1">
            <Card className="shadow-2xl">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onNavigateToLogin}
                  >
                    <ArrowLeft className="size-4 mr-2" />
                    Back to Login
                  </Button>
                </div>
                <CardTitle>Voter Registration</CardTitle>
                <CardDescription>
                  Create your account to participate in elections
                </CardDescription>
              </CardHeader>
              <CardContent>
                {currentStep === 1 && (
                  <form onSubmit={handleStep1Submit} className="space-y-4">
                    <div>
                      <Label htmlFor="name">Full Name *</Label>
                      <Input
                        id="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="John Doe"
                        className="mt-2"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="your@email.com"
                        className="mt-2"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="phone">Phone Number (Optional)</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="+1 (555) 123-4567"
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label htmlFor="date-of-birth">Date of Birth *</Label>
                      <Input
                        id="date-of-birth"
                        type="date"
                        value={dateOfBirth}
                        onChange={(e) => setDateOfBirth(e.target.value)}
                        className="mt-2"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="address">Address *</Label>
                      <Input
                        id="address"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        placeholder="123 Main St, Anytown, USA"
                        className="mt-2"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="password">Password *</Label>
                      <Input
                        id="password"
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••"
                        className="mt-2"
                        required
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        Must be at least 6 characters long
                      </p>
                    </div>

                    <div>
                      <Label htmlFor="confirm-password">Confirm Password *</Label>
                      <Input
                        id="confirm-password"
                        type="password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="••••••••"
                        className="mt-2"
                        required
                      />
                    </div>

                    <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg">
                      <p className="text-sm text-blue-800">
                        By registering, you agree to our Terms of Service and Privacy Policy. Your vote will be anonymous and secure.
                      </p>
                    </div>

                    <Button type="submit" className="w-full" size="lg">
                      Next
                    </Button>
                  </form>
                )}

                {currentStep === 2 && (
                  <div className="space-y-4">
                    <div className="mb-4">
                      <h3 className="font-semibold mb-2">Step 2: Identity Verification</h3>
                      <p className="text-sm text-gray-600">
                        Upload any government-issued ID for verification purposes
                      </p>
                    </div>

                    <div>
                      <Label htmlFor="voter-id-document">Upload ID Document *</Label>
                      <Input
                        id="voter-id-document"
                        type="file"
                        accept="image/*,application/pdf"
                        onChange={handleVoterIdUpload}
                        className="mt-2"
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        Upload a clear image or PDF of any government ID (Driver's License, Passport, etc.) - max 5MB
                      </p>
                    </div>

                    {voterIdDocument && (
                      <div className="border rounded-lg p-4 bg-green-50">
                        <div className="flex items-center gap-2 text-green-700">
                          <CheckCircle className="size-5" />
                          <span className="font-medium">Document uploaded successfully!</span>
                        </div>
                      </div>
                    )}

                    <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg">
                      <p className="text-sm text-blue-800">
                        <strong>Note:</strong> Your official Voter ID will be generated and provided by the admin after 
                        your registration is approved. This document is only for identity verification.
                      </p>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setCurrentStep(1)}
                        className="flex-1"
                      >
                        Back
                      </Button>
                      <Button
                        type="button"
                        onClick={handleStep2Submit}
                        className="flex-1"
                        size="lg"
                        disabled={!voterIdDocument}
                      >
                        Next: Face Capture
                      </Button>
                    </div>
                  </div>
                )}

                {currentStep === 3 && (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="face-capture">Capture Your Face *</Label>
                      <FaceCapture onCapture={handleFaceCapture} />
                    </div>

                    <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg">
                      <p className="text-sm text-blue-800">
                        By registering, you agree to our Terms of Service and Privacy Policy. Your vote will be anonymous and secure.
                      </p>
                    </div>

                    <Button type="submit" className="w-full" size="lg">
                      Register as Voter
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right side - Branding */}
          <div className="md:col-span-1 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2 mb-6">
              <Vote className="size-12 text-blue-600" />
              <h1 className="text-4xl">ElectionHub</h1>
            </div>
            <h2 className="text-2xl mb-4">Register as a Voter</h2>
            <p className="text-lg text-gray-600 mb-8">
              Join thousands of citizens making their voice heard through secure digital voting.
            </p>
          </div>
        </div>

        {/* Face Capture Dialog */}
        <Dialog open={showFaceCapture} onOpenChange={setShowFaceCapture}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Face Capture - Step 3</DialogTitle>
              <DialogDescription>
                Please capture your face to complete the registration process.
              </DialogDescription>
            </DialogHeader>
            <FaceCapture onCapture={handleFaceCapture} />
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}