import { useState, useRef } from "react";
import { Button } from "./ui/button";
import { Camera, Upload, CheckCircle, XCircle } from "lucide-react";
import { toast } from "sonner";

interface QRCodeScannerProps {
  onScanSuccess: (voterId: string) => void;
  onScanError?: (error: string) => void;
}

export function QRCodeScanner({ onScanSuccess, onScanError }: QRCodeScannerProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [scannedData, setScannedData] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Simulate QR code scanning from image
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const imageData = event.target?.result as string;
      
      // Simulate QR code decoding
      // In production, use a library like jsQR or html5-qrcode
      setTimeout(() => {
        // Extract voter data from image (simulated)
        // For demo, we'll parse the image data URL to find VID pattern
        const mockVoterData = extractMockVoterData(imageData);
        
        if (mockVoterData) {
          setScannedData(mockVoterData);
          toast.success("QR Code scanned successfully!");
          onScanSuccess(mockVoterData);
        } else {
          toast.error("Failed to read QR code. Please try again.");
          onScanError?.("Invalid QR code");
        }
        setIsScanning(false);
      }, 1500);
    };
    
    setIsScanning(true);
    reader.readAsDataURL(file);
  };

  const extractMockVoterData = (imageData: string): string | null => {
    // This is a mock function. In production, use a proper QR code decoder
    // For testing, we'll return a sample voter ID
    // You could parse actual QR codes from the VoterIDCard component
    
    // Try to extract VID from QR code data (simulated)
    const sampleVoterIds = [
      "VID-2025-000001",
      "VID-2025-000002",
      "VID-2025-123456",
      "VID-2025-789012"
    ];
    
    // Return a random sample for demo (in production, this would decode the actual QR)
    return sampleVoterIds[Math.floor(Math.random() * sampleVoterIds.length)];
  };

  const handleManualEntry = () => {
    const voterId = prompt("Enter Voter ID from QR Code:");
    if (voterId) {
      setScannedData(voterId);
      onScanSuccess(voterId);
      toast.success("Voter ID entered successfully!");
    }
  };

  return (
    <div className="space-y-4">
      <div className="text-center">
        <h3 className="font-semibold mb-2">Scan Your Voter ID QR Code</h3>
        <p className="text-sm text-gray-600">
          Upload a photo of your Voter ID card's QR code
        </p>
      </div>

      <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
        {!scannedData ? (
          <>
            {isScanning ? (
              <div className="py-8">
                <Camera className="size-12 mx-auto mb-3 text-blue-600 animate-pulse" />
                <p className="text-gray-600">Scanning QR code...</p>
              </div>
            ) : (
              <div className="space-y-4">
                <Camera className="size-12 mx-auto text-gray-400" />
                <p className="text-gray-600">
                  Take a photo or upload an image of your Voter ID card
                </p>
                
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageUpload}
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                />
                
                <div className="flex flex-col gap-2">
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full"
                  >
                    <Upload className="size-4 mr-2" />
                    Upload QR Code Image
                  </Button>
                  
                  <Button
                    onClick={handleManualEntry}
                    variant="outline"
                    className="w-full"
                  >
                    Enter Voter ID Manually
                  </Button>
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="py-8">
            <CheckCircle className="size-12 mx-auto mb-3 text-green-600" />
            <p className="font-semibold mb-2">QR Code Scanned Successfully!</p>
            <p className="text-sm text-gray-600 mb-4">Voter ID: {scannedData}</p>
            <Button
              onClick={() => {
                setScannedData(null);
                if (fileInputRef.current) {
                  fileInputRef.current.value = "";
                }
              }}
              variant="outline"
              size="sm"
            >
              Scan Again
            </Button>
          </div>
        )}
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
        <p className="text-xs text-blue-800">
          <strong>Tip:</strong> For best results, ensure the QR code is clearly visible and well-lit. 
          You can find the QR code on your digital Voter ID card sent to your email.
        </p>
      </div>
    </div>
  );
}
