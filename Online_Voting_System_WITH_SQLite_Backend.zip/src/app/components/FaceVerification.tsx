import { useRef, useState, useCallback } from "react";
import Webcam from "react-webcam";
import { Button } from "./ui/button";
import { Camera, CheckCircle, XCircle, Image, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface FaceVerificationProps {
  storedFacePhoto: string;
  onVerificationComplete: (success: boolean, similarity: number) => void;
  threshold?: number; // Similarity threshold (0-100)
}

export function FaceVerification({ 
  storedFacePhoto, 
  onVerificationComplete,
  threshold = 70 
}: FaceVerificationProps) {
  const webcamRef = useRef<Webcam>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [cameraError, setCameraError] = useState(false);

  const simulateFaceComparison = (img1: string, img2: string): number => {
    // Mock similarity score between 70-95% for demo purposes
    // In a real app, you'd use a face recognition library or API
    return Math.floor(Math.random() * 25) + 70;
  };

  const capture = useCallback(() => {
    const imageSrc = webcamRef.current?.getScreenshot();
    if (imageSrc) {
      setCapturedImage(imageSrc);
      toast.success("Face captured!");
    } else {
      toast.error("Failed to capture image. Please try again.");
    }
  }, [webcamRef]);

  const useSamplePhoto = () => {
    // Generate a sample placeholder image
    const canvas = document.createElement('canvas');
    canvas.width = 640;
    canvas.height = 480;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
      // Background gradient
      const gradient = ctx.createLinearGradient(0, 0, 0, 480);
      gradient.addColorStop(0, '#10b981');
      gradient.addColorStop(1, '#059669');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, 640, 480);
      
      // Face circle
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(320, 200, 80, 0, Math.PI * 2);
      ctx.fill();
      
      // Eyes
      ctx.fillStyle = '#10b981';
      ctx.beginPath();
      ctx.arc(295, 190, 12, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(345, 190, 12, 0, Math.PI * 2);
      ctx.fill();
      
      // Smile
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(320, 210, 25, 0.2, Math.PI - 0.2);
      ctx.stroke();
      
      // Body
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(250, 280, 140, 200);
      
      // Text
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 24px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('VERIFICATION SAMPLE', 320, 420);
      ctx.font = '16px Arial';
      ctx.fillText('For Testing Purpose Only', 320, 450);
      
      const sampleImage = canvas.toDataURL('image/jpeg');
      setCapturedImage(sampleImage);
      toast.success("Sample photo loaded for testing!");
    }
  };

  const verify = async () => {
    if (!capturedImage) {
      toast.error("Please capture a photo first");
      return;
    }

    setIsVerifying(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 2000));

    const similarity = simulateFaceComparison(storedFacePhoto, capturedImage);
    const success = similarity >= threshold;

    setIsVerifying(false);

    if (success) {
      toast.success(`Face verified! Match: ${similarity}%`);
      onVerificationComplete(true, similarity);
    } else {
      toast.error(`Verification failed. Match: ${similarity}% (Required: ${threshold}%)`);
      onVerificationComplete(false, similarity);
    }
  };

  const retake = () => {
    setCapturedImage(null);
    setCameraError(false);
  };

  const handleUserMedia = () => {
    setIsCameraReady(true);
    setCameraError(false);
  };

  const handleUserMediaError = () => {
    setCameraError(true);
    toast.error("Camera access denied or not available");
  };

  const videoConstraints = {
    width: 1280,
    height: 720,
    facingMode: "user"
  };

  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        {/* Stored Face */}
        <div className="space-y-2">
          <h4 className="font-medium text-center">Registered Photo</h4>
          <div className="relative bg-gray-100 rounded-lg overflow-hidden aspect-video">
            <img src={storedFacePhoto} alt="Stored face" className="w-full h-full object-cover" />
          </div>
        </div>

        {/* Current Capture */}
        <div className="space-y-2">
          <h4 className="font-medium text-center">Live Verification</h4>
          <div className="relative bg-gray-100 rounded-lg overflow-hidden aspect-video">
            {!capturedImage ? (
              <>
                {!cameraError ? (
                  <>
                    <Webcam
                      ref={webcamRef}
                      audio={false}
                      screenshotFormat="image/jpeg"
                      videoConstraints={videoConstraints}
                      onUserMedia={handleUserMedia}
                      onUserMediaError={handleUserMediaError}
                      className="w-full h-full object-cover"
                    />
                    {!isCameraReady && (
                      <div className="absolute inset-0 flex items-center justify-center bg-gray-200">
                        <div className="text-center">
                          <Camera className="size-8 mx-auto mb-2 text-gray-400 animate-pulse" />
                          <p className="text-sm text-gray-600">Loading camera...</p>
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center bg-gray-200">
                    <div className="text-center p-4">
                      <Camera className="size-8 mx-auto mb-2 text-gray-400" />
                      <p className="text-xs text-gray-600 mb-3">Camera not available</p>
                      <Button onClick={useSamplePhoto} size="sm" variant="outline">
                        <Image className="size-3 mr-1" />
                        Use Sample
                      </Button>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <img src={capturedImage} alt="Captured face" className="w-full h-full object-cover" />
            )}
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-2">
        {!capturedImage ? (
          <>
            <Button
              onClick={capture}
              disabled={!isCameraReady || cameraError}
              className="flex-1"
              size="lg"
            >
              <Camera className="size-4 mr-2" />
              Capture Photo
            </Button>
            <Button
              onClick={useSamplePhoto}
              variant="outline"
              className="flex-1"
              size="lg"
            >
              <Image className="size-4 mr-2" />
              Use Sample Photo
            </Button>
          </>
        ) : (
          <>
            <Button
              onClick={retake}
              variant="outline"
              className="flex-1"
              size="lg"
            >
              Retake
            </Button>
            <Button
              onClick={verify}
              className="flex-1"
              size="lg"
              disabled={isVerifying}
            >
              {isVerifying ? (
                <>
                  <Loader2 className="size-4 mr-2 animate-spin" />
                  Verifying...
                </>
              ) : (
                <>
                  <CheckCircle className="size-4 mr-2" />
                  Verify Face
                </>
              )}
            </Button>
          </>
        )}
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
        <p className="text-xs text-blue-800">
          <strong>Note:</strong> If camera is not working, use "Use Sample Photo" button for testing purposes.
          The system will compare your live photo with your registered photo.
        </p>
      </div>
    </div>
  );
}